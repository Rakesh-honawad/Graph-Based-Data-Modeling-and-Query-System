# Claude (claude.ai) — Session Log
**Project:** Graph-Based Data Modeling & Query System (O2C Intelligence)
**Phase:** Core architecture, LLM pipeline design, prompting strategy, debugging
**Model:** Claude Sonnet
**Date:** Throughout development

---

## Session 1 — Initial Architecture Design

**Me:**
> I have a technical assignment: build a graph-based data modeling and query system for SAP Order-to-Cash data. I have 19 entity types as JSONL files. Users should be able to visualize the graph and ask natural language questions against it.
>
> Help me think through the architecture. Key questions:
> 1. Should I use a dedicated graph DB (Neo4j) or model graph in a relational DB?
> 2. What's the right LLM integration pattern for NL queries against structured data?
> 3. What frontend library for graph visualization?
>
> I want clean, defensible architecture decisions — not just whatever is easiest.

**Claude:**
Good framing — let me work through each decision with the tradeoffs explicit.

**1. Graph DB vs Relational**

For ~700 nodes and ~2000 edges, Neo4j is genuinely overkill. The real value of Neo4j emerges at:
- Scale (millions of nodes where SQL joins become expensive)
- Complex multi-hop queries that Cypher expresses more naturally than SQL
- Changing schema (property graphs are schema-flexible)

For your scope: SQLite with two tables (`graph_nodes`, `graph_edges`) gives you identical expressive power. BFS in Python over SQL is fast at this scale (~2-5ms per hop). Zero operational overhead.

The architectural argument: "I chose SQLite because the scale doesn't justify Neo4j's operational overhead, and BFS traversal in Python over SQL is performant for sub-1000 node graphs. This is a deliberate tradeoff for maintainability and deployability." That's a strong answer.

**2. NL→SQL LLM Pattern**

There are two main patterns:
- **RAG over documents**: Good for prose questions about unstructured content. Wrong fit here.
- **NL→SQL (text-to-SQL)**: Right fit. The LLM translates the question into SQL, you execute it against real data, then the LLM formats the result.

Critical insight: separate the SQL generation (structured, testable) from the response formatting (flexible prose). Don't mix them in one prompt — the output format becomes inconsistent.

**Two-call pattern:**
- Call 1: `question + schema + examples → { intent, sql, answer_template }` (JSON output)
- Call 2: `question + sql + results → natural language answer`

This is more reliable than one-call because each call is specialized. Call 1 can be unit-tested independently.

**3. Graph Visualization**

D3.js is the right choice for full SVG control and custom node styling. The catch: D3's force simulation runs at 60fps via DOM mutation — you must keep it in a `useRef`, not React state. Otherwise each tick triggers a React re-render and you get 1fps performance.

The pattern: `useGraph.js` hook owns all D3 lifecycle. React only re-runs the hook when the data prop changes. D3 manages its own DOM subtree.

**Recommended stack:**
- FastAPI + SQLite + Python (BFS, ETL, guardrails)
- React 18 + D3.js v7 (visualization)
- Gemini/Groq (free tier LLMs for NL→SQL)
- Vercel (frontend) + Render (backend) for free deployment

---

## Session 2 — LLM System Prompt Design for NL→SQL

**Me:**
> Help me design the system prompt for Call 1 (NL → SQL). I need the LLM to:
> - Only generate SELECT queries
> - Return structured JSON: { intent, sql, answer_template }
> - Handle the SAP O2C domain correctly
> - Include few-shot examples
>
> Here's my SQLite schema: [pasted 19 table schemas]

**Claude:**
Here's the system prompt structure I'd recommend. The key principles:

1. **Schema first** — the LLM needs the full schema to generate accurate SQL. Don't summarize it.
2. **Output format specified exactly** — tell it exactly what JSON structure you want
3. **Domain restriction in the prompt** — reinforce the keyword guardrail at the LLM layer too
4. **Few-shot examples** — 4 examples covering the query patterns you expect: aggregation, trace, gap detection, date filter

```python
SYSTEM_PROMPT_SQL = """You are a SQL expert for an SAP Order-to-Cash (O2C) data system.

SCHEMA:
{schema}

Your task: Convert the user's natural language question into a SQLite SELECT query.

OUTPUT FORMAT — respond ONLY with this JSON, no other text:
{{
  "intent": "brief description of what the user is asking",
  "sql": "SELECT ... FROM ...",
  "answer_template": "brief template for how to phrase the answer"
}}

RULES:
- Only generate SELECT queries. Never INSERT, UPDATE, DELETE, DROP, or ALTER.
- Only reference tables and columns that exist in the schema above.
- If the question cannot be answered from the available data, return null for sql.
- The question is about SAP O2C data only. Refuse non-O2C questions.

FEW-SHOT EXAMPLES:

Q: "Which products have the most billing documents?"
A: {{
  "intent": "rank materials by billing document count",
  "sql": "SELECT m.material_id, m.description, COUNT(bd.billing_id) as billing_count FROM materials m JOIN billing_document_items bdi ON m.material_id = bdi.material_id JOIN billing_documents bd ON bdi.billing_id = bd.billing_id GROUP BY m.material_id ORDER BY billing_count DESC LIMIT 10",
  "answer_template": "The top products by billing count are: {{results}}"
}}

Q: "Show me sales orders that were delivered but never billed"
A: {{
  "intent": "find gap in O2C flow - delivered but unbilled orders",
  "sql": "SELECT so.order_id, so.customer_id, so.net_value FROM sales_orders so JOIN outbound_deliveries od ON so.order_id = od.sales_order_id LEFT JOIN billing_documents bd ON so.order_id = bd.sales_order_id WHERE bd.billing_id IS NULL",
  "answer_template": "{{count}} sales orders were delivered but never invoiced: {{results}}"
}}

Q: "Trace the full flow for billing document 90504262"
A: {{
  "intent": "full O2C chain trace for a specific billing document",
  "sql": "SELECT bd.billing_id, bd.net_value, so.order_id, c.name as customer_name, od.delivery_id, p.payment_id, p.amount FROM billing_documents bd LEFT JOIN sales_orders so ON bd.sales_order_id = so.order_id LEFT JOIN customers c ON so.customer_id = c.customer_id LEFT JOIN outbound_deliveries od ON so.order_id = od.sales_order_id LEFT JOIN payments p ON bd.billing_id = p.billing_document_id WHERE bd.billing_id = '90504262'",
  "answer_template": "The O2C chain for billing document 90504262: {{results}}"
}}

Q: "What is the total payment received this month?"
A: {{
  "intent": "aggregate total payment amount for current month",
  "sql": "SELECT SUM(amount) as total_payments, COUNT(*) as payment_count FROM payments WHERE strftime('%Y-%m', payment_date) = strftime('%Y-%m', 'now')",
  "answer_template": "Total payments received this month: {{results}}"
}}
"""
```

The `answer_template` field in the JSON is useful for Call 2 — it tells the prose-formatting LLM how the answer should be framed.

**Me:** How should I handle the schema injection? The full schema is long.

**Claude:**
Build the schema string dynamically from SQLite's `sqlite_master`:

```python
def get_schema_string(conn) -> str:
    tables = conn.execute(
        "SELECT name, sql FROM sqlite_master WHERE type='table' ORDER BY name"
    ).fetchall()
    return '\n\n'.join([f"-- {name}\n{sql}" for name, sql in tables if sql])
```

Cache it at startup — it doesn't change at runtime. Pass it into the system prompt once per app lifecycle, not per request.

---

## Session 3 — Debugging: LLM Returning Malformed JSON

**Me:**
> My Call 1 is sometimes returning the JSON wrapped in markdown code fences like:
> ` ```json\n{"intent": ...}\n``` `
> instead of raw JSON. My `json.loads()` is crashing. How do I handle this reliably?

**Claude:**
This is a classic LLM output handling issue. Two approaches:

**Approach 1 — Strip fences before parsing (robust):**
```python
import re

def extract_json(text: str) -> dict:
    # Strip markdown code fences if present
    text = text.strip()
    text = re.sub(r'^```(?:json)?\s*', '', text)
    text = re.sub(r'\s*```$', '', text)
    text = text.strip()
    return json.loads(text)
```

**Approach 2 — Use the LLM provider's native JSON mode:**
Both Gemini and Groq support `response_mime_type: "application/json"` which forces raw JSON output. This is more reliable than stripping fences.

For Gemini:
```python
response = model.generate_content(
    prompt,
    generation_config=genai.GenerationConfig(
        response_mime_type="application/json"
    )
)
```

**Recommendation:** Use both. JSON mode as primary, fence-stripping as fallback. Defense in depth.

**Me:** Implemented both. Now getting an occasional `null` SQL from the LLM for valid O2C questions. How do I improve the prompt to reduce this?

**Claude:**
The `null` SQL usually happens when the LLM is uncertain about a column name or table relationship. Add a "schema hints" section to your system prompt that explicitly maps common natural language terms to schema fields:

```
SCHEMA HINTS (use these mappings when generating SQL):
- "customer" → customers.customer_id or customers.name
- "order" → sales_orders.order_id
- "delivery" / "shipped" → outbound_deliveries
- "invoice" / "billed" → billing_documents
- "payment" / "paid" → payments
- "product" / "material" / "item" → materials or sales_order_items
- "plant" / "warehouse" → plants
- "amount" / "value" → net_value (orders/billing) or amount (payments)
```

This reduces ambiguity and the LLM is less likely to punt to `null`.

---

## Session 4 — Conversation Memory Implementation

**Me:**
> I want to support follow-up questions in the chat. Like the user asks "show me top customers" then "what about last month?" — how do I implement conversation memory without it getting expensive?

**Claude:**
The standard approach: maintain a sliding window of the last N turns per session. N=4 (4 user+assistant pairs = 8 messages) is the sweet spot — enough for meaningful follow-up, cheap enough to include in every request.

Implementation:

```python
from collections import defaultdict, deque

# In-memory session store (per-process, resets on restart — fine for demo)
sessions: dict[str, deque] = defaultdict(lambda: deque(maxlen=8))  # 4 turns * 2

def get_chat_response(session_id: str, question: str) -> dict:
    history = list(sessions[session_id])
    
    messages = history + [{"role": "user", "content": question}]
    
    # Call 1: NL → SQL with full history
    response = llm_client.chat(
        system=SYSTEM_PROMPT_SQL,
        messages=messages
    )
    
    # Update history
    sessions[session_id].append({"role": "user", "content": question})
    sessions[session_id].append({"role": "assistant", "content": response.text})
    
    return parse_and_execute(response)
```

Note: in-memory sessions reset on server restart. For a demo this is fine. For production you'd use Redis or a DB-backed session store.

---

## Session 5 — D3 Node Highlighting from Chat Response

**Me:**
> When the chat returns a response, I want to highlight the relevant graph nodes. The API returns `highlighted_nodes: ["SO-1001", "BD-9050"]`. How do I connect the chat response to the D3 graph without React re-rendering the whole graph?

**Claude:**
This is the key challenge with D3 in React — you want to update visual properties without re-running the full simulation. The solution: keep a separate `highlight` state in React, and in the D3 `useGraph` hook, add a `useEffect` that watches for changes to the highlighted set and updates node visual properties directly via D3 selection.

```javascript
// In App.jsx - separate concerns
const [graphData, setGraphData] = useState(null);    // triggers full D3 re-init
const [highlighted, setHighlighted] = useState([]);  // only triggers highlight update

// In useGraph.js
useEffect(() => {
  if (!svgRef.current || !highlighted) return;
  
  const highlightSet = new Set(highlighted);
  
  d3.select(svgRef.current)
    .selectAll('.node circle')
    .transition().duration(300)
    .attr('opacity', d => 
      highlighted.length === 0 ? 1 : 
      highlightSet.has(d.id) ? 1 : 0.2
    )
    .attr('stroke', d => highlightSet.has(d.id) ? '#ffffff' : 'none')
    .attr('stroke-width', d => highlightSet.has(d.id) ? 2 : 0);
    
}, [highlighted]);  // Only runs when highlighted changes — NOT on graph data change
```

This way: `graphData` change → full D3 re-init. `highlighted` change → lightweight DOM update only. Clean separation.

---

## Session 6 — README Architecture Section Review

**Me:**
> Here's my draft README architecture decisions section. Review it and suggest improvements to make the reasoning sharper and more defensible for a technical evaluation.
> [pasted draft]

**Claude:**
The decisions are sound. Here's what I'd sharpen:

1. **SQLite decision** — add the explicit scale threshold: "At sub-1000 nodes, BFS over SQL joins adds only 2-5ms per hop." Numbers make the argument concrete.

2. **D3 via useRef** — clarify WHY not React state: "D3's simulation runs at 60fps via direct DOM mutation. Routing that through React's reconciler causes continuous re-renders." The mechanism matters, not just the conclusion.

3. **Two-call LLM pattern** — add the testability argument: "Call 1 can be unit tested independently — is the generated SQL correct? Call 2 can be swapped without touching SQL logic."

4. **zoomFit** — this is a nice detail that shows attention to UX. Keep it.

5. **Missing decision** — add a note on the warm stone palette being intentional differentiation, not random. Evaluators will notice the visual is distinctive.

[Proceeded to revise README based on this feedback]

---

## Session 7 — Final Debugging: Graph Not Re-rendering After Chat Highlight

**Me:**
> The highlighting works the first time I send a chat message, but after that it stops working. The `highlighted` state updates (I can see it in React DevTools) but the D3 nodes don't change visually.

**Claude:**
Classic stale closure bug. Your `useEffect` for highlighting is capturing the initial D3 selections in a closure. When the graph data changes (e.g., you expand a node), new DOM elements are created, but the old effect closure still references the old selection.

Fix: make the highlight effect depend on a stable ref that always has the current SVG reference, not a stale closure:

```javascript
// Add this ref
const highlightedRef = useRef([]);

// Update it when state changes
useEffect(() => {
  highlightedRef.current = highlighted;
  applyHighlight(highlighted);  // call the imperative function
}, [highlighted]);

// The imperative function always reads from live DOM
const applyHighlight = useCallback((ids) => {
  if (!svgRef.current) return;
  const highlightSet = new Set(ids);
  
  // Fresh selection every time — no stale closure
  d3.select(svgRef.current)
    .selectAll('.node circle')
    // ... rest of highlight logic
}, []);  // no deps — reads from DOM directly
```

The key: `d3.select(svgRef.current).selectAll(...)` always queries the current DOM. It's not captured in a closure — it runs fresh each time.

**Me:** That fixed it. The stale closure wasn't obvious — I was looking at state updates in DevTools and didn't realize the effect was using old selections.

**Claude:** This is one of the trickiest patterns with D3+React. The rule of thumb: any D3 that reads from the DOM should use `d3.select().selectAll()` at call time, not cached in a variable. The DOM is always fresh; JS closures are not.

---

## Summary

Claude was the primary tool for:
- Architecture decisions and tradeoff reasoning
- LLM prompting strategy and system prompt design
- Core pipeline implementation (NL→SQL, guardrails, conversation memory)
- D3+React integration pattern
- Debugging non-obvious bugs (stale closures, JSON parsing)
- README review and sharpening

Total sessions: ~12 across the full development cycle.
