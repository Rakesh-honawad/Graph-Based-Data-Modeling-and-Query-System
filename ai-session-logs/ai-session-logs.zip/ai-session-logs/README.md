# AI Session Logs — O2C Intelligence

This folder contains session logs from all AI tools used during development of the Graph-Based Data Modeling & Query System.

## Tool Usage Overview

| Tool | Primary Role | Log File |
|---|---|---|
| **Perplexity** | Research & tech stack decisions | `perplexity-research-session.md` |
| **ChatGPT (GPT-4o)** | Environment setup & deployment debugging | `chatgpt-setup-session.md` |
| **GitHub Copilot** | In-editor completions & boilerplate | `copilot-session-log.md` |
| **Google Gemini** | Frontend CSS design & color palette | `gemini-frontend-design-session.md` |
| **Claude** | Architecture, LLM pipeline, prompting strategy, debugging | `claude-session-log-v2.md` |

## How I Used AI During This Project

### Research Phase (Perplexity)
Used Perplexity for deep comparative research — SQLite vs Neo4j, LLM provider benchmarks, D3 vs Cytoscape. Perplexity's multi-source synthesis with citations made it the right tool for architectural decision-making where I needed to weigh multiple credible perspectives before committing to a direction.

### Setup & DevOps (ChatGPT)
ChatGPT was my go-to for quick environment and deployment fixes: pip errors, CORS configuration, Render/Vercel setup, path resolution bugs. These are fast, well-defined problems where ChatGPT's broad training on Stack Overflow-style Q&A is effective.

### In-Editor Coding (GitHub Copilot)
Copilot handled boilerplate I knew conceptually but didn't want to hand-type: JSONL loaders, BFS skeleton, D3 force simulation setup, CSS animations. All Copilot suggestions were reviewed and modified for domain-specific correctness — the O2C schema, node types, and edge relationships came from my own design.

### Frontend Design (Gemini)
Used Gemini specifically for the visual design layer — it has strong aesthetic sensibility for color palettes and CSS generation. The warm stone palette (terracotta/cream vs generic blue/purple) came from a Gemini session focused on differentiating the tool visually. The full `tokens.css` was Gemini-generated and manually refined.

### Architecture & Core Logic (Claude)
Claude was the primary tool for decisions requiring sustained reasoning: architecture tradeoffs, LLM prompting strategy, the two-call NL→SQL pipeline, guardrail design, D3+React integration patterns, and debugging complex bugs (stale closures, JSON parsing edge cases). Claude's strength here was being able to work through multi-step reasoning and explain *why* a decision was right, not just *what* to do.

## Prompting Approach

Across all tools, my prompting approach followed these principles:

1. **Provide full context**: pasted actual schema, actual error messages, actual code — not abstractions
2. **State the constraint**: "free tier", "demo scale", "defensible for technical evaluation" — these shaped better answers
3. **Ask for tradeoffs**: "what are the tradeoffs vs X?" produced better architecture reasoning than "how do I do X?"
4. **Iterate on output**: never accepted first responses wholesale — always reviewed, modified, and tested
5. **Domain-specific validation**: LLM suggestions for O2C schema details were always verified against the actual data

The best prompt pattern for architecture questions: *"I need to make a decision between A and B for [specific constraint]. Help me reason through the tradeoffs. I want a defensible answer, not just the easiest one."*
