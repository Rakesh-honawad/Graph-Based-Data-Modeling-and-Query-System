# Perplexity AI — Research Session Log
**Project:** Graph-Based Data Modeling & Query System (O2C Intelligence)
**Phase:** Pre-build research & architecture decisions
**Date:** Early development

---

## Session 1 — Graph DB vs Relational for ~700 Nodes

**Query:**
> "For a project with ~700 graph nodes and ~2000 edges representing SAP O2C data, is Neo4j overkill? What are the tradeoffs vs SQLite with adjacency tables?"

**Perplexity Response Summary:**
Perplexity pulled from multiple sources (Neo4j docs, SQLite benchmarks, Stack Overflow discussions) and surfaced the key tradeoff clearly:

- Neo4j shines at **multi-hop traversals at scale** (millions of nodes, complex Cypher queries)
- For sub-1000 nodes, **SQLite with `graph_nodes` + `graph_edges` tables** is functionally equivalent
- BFS in Python over SQL joins adds ~2-5ms per hop at this scale — well within acceptable range
- Operational overhead of Neo4j (separate process, auth, backup) is significant for a demo/assignment project
- Referenced articles from: *Graph Databases in Action* (Manning), Neo4j blog on when-not-to-use-neo4j

**My Decision:** SQLite. Zero ops overhead. Git-committable `.db` file. BFS in Python is readable and testable.

---

## Session 2 — LLM Provider Comparison for NL→SQL

**Query:**
> "Compare Google Gemini Flash, Groq (Llama 3.1), and OpenAI GPT-4o-mini for a text-to-SQL task on a SQLite schema. Priorities: free tier availability, latency, JSON output reliability."

**Perplexity Response Summary:**
Compiled a comparison across provider documentation and independent benchmarks:

| Provider | Free Tier | Avg Latency | JSON Mode | SQL Accuracy |
|---|---|---|---|---|
| Gemini 1.5 Flash | ✅ Generous | ~800ms | ✅ | High |
| Groq (Llama 3.1 70B) | ✅ Rate-limited | ~300ms | ✅ | High |
| GPT-4o-mini | ❌ Paid | ~600ms | ✅ | Very High |
| Claude 3 Haiku | ❌ Paid | ~700ms | ✅ | Very High |

- Groq stands out for **raw speed** due to custom inference chips
- Gemini Flash has the most generous free tier with **15 RPM and 1M tokens/day**
- Both support structured JSON output, which is critical for the NL→SQL pipeline

**My Decision:** Support both Gemini and Groq via `LLM_PROVIDER` env var. Gemini as default (better free tier), Groq as fallback for speed.

---

## Session 3 — D3.js vs Cytoscape.js vs Sigma.js for Graph Viz

**Query:**
> "Comparing D3.js force layout vs Cytoscape.js vs Sigma.js for rendering a ~700 node interactive graph in React. Need: zoom, node expand-on-click, custom color per node type, hover tooltips."

**Perplexity Response Summary:**
- **D3.js**: Most control, steepest learning curve, best for custom visuals. Requires `useRef` pattern in React to avoid reconciler conflicts. Force simulation gives natural layout.
- **Cytoscape.js**: Graph-specific API, easier to get started, good for network analysis. Less expressive for custom styling.
- **Sigma.js**: Best for 10k+ nodes (WebGL-based). Overkill for 700 nodes.
- Community threads noted D3 + `useRef` is the preferred pattern in production React graph apps

**My Decision:** D3.js. Gives full SVG control, custom node colors, zoom/pan built-in. Worth the complexity for the visual quality.

---

## Session 4 — ETL Strategy for 19 JSONL Entity Types

**Query:**
> "Best approach for ingesting 19 different JSONL entity types into a single SQLite graph. Each entity type has different schema. Need: deduplication, relationship inference, graph_nodes + graph_edges tables."

**Perplexity Response Summary:**
- Suggested a **two-pass ETL**: Pass 1 builds entity tables and inserts into `graph_nodes`. Pass 2 infers edges from foreign key patterns across entity types.
- Deduplication strategy: use entity ID as the primary key and `INSERT OR REPLACE`
- For relationship inference: define a static edge-config map (`{source_type, source_fk_field, target_type}`) to avoid hardcoding per-entity logic
- Referenced SQLite docs on WAL mode for concurrent read performance

**My Decision:** Two-pass ETL with a static `EDGE_CONFIG` dictionary. Clean separation between ingestion and graph construction.

---

## Session 5 — Guardrail Patterns for Domain-Restricted LLM Chat

**Query:**
> "What are common patterns for restricting an LLM chatbot to only answer questions within a specific domain (SAP O2C in my case)? Looking for lightweight, no-extra-LLM-call approaches."

**Perplexity Response Summary:**
- **Keyword gate** (pre-filter): Check for domain keywords before calling LLM. Zero cost, fast. Tradeoff: can reject valid paraphrased questions.
- **System prompt reinforcement**: Include explicit domain boundary instructions in system prompt. LLM self-enforces.
- **Output validation**: Check that generated SQL only references allowed tables.
- **Classifier model**: Most robust but adds latency and cost — overkill for assignment scope.

Referenced: Anthropic prompt engineering docs, OpenAI cookbook on system prompt guardrails

**My Decision:** Three-layer approach — keyword gate (no LLM cost) + SQL safety check (regex) + system prompt reinforcement. Layered defense without extra LLM calls.

---

## Session 6 — Deployment: Vercel (frontend) + Render (backend) Free Tier Feasibility

**Query:**
> "Can a FastAPI backend with SQLite and a React frontend be deployed for free on Render + Vercel respectively? Any known limitations for a demo project?"

**Perplexity Response Summary:**
- Vercel free tier: perfect for static React builds, auto-deploy from GitHub main. No limitations for this use case.
- Render free tier: FastAPI works via `uvicorn` with a `Procfile`. Key limitation: **instance spins down after 15 mins of inactivity**, causing cold start delays of ~30s.
- SQLite on Render: works on ephemeral disk. Data resets on redeploy — acceptable for a demo that re-runs ETL.
- Suggested adding a `/health` endpoint that Render can ping to keep instance warm.

**My Decision:** Vercel + Render. Added health endpoint. Documented cold-start behavior in README.

---

*All research informed architecture decisions documented in README.md under "Architecture Decisions & Tradeoffs".*
