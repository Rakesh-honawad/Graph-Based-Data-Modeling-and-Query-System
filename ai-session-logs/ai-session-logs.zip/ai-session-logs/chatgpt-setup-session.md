# ChatGPT (GPT-4o) — Session Log
**Project:** Graph-Based Data Modeling & Query System (O2C Intelligence)
**Phase:** Environment setup, dependency issues, deployment configuration
**Date:** Mid-development

---

## Session 1 — Python Environment Setup Issue

**Me:**
> I'm getting this error when running `pip install -r requirements.txt`:
> `ERROR: Could not build wheels for greenlet, which is required to install pyproject.toml-based projects`
> Python 3.11, macOS Ventura. How do I fix this?

**ChatGPT:**
This is a common Xcode/clang toolchain mismatch. Try:
```bash
xcode-select --install
pip install --upgrade pip setuptools wheel
pip install -r requirements.txt
```
If greenlet is only needed for SQLAlchemy async and you're using synchronous SQLite connections, you can also just remove it from requirements.txt since you won't need it.

**Outcome:** Removed greenlet from requirements.txt (wasn't using async SQLAlchemy). Problem resolved.

---

## Session 2 — CORS Error Blocking Frontend→Backend

**Me:**
> My React app on localhost:3000 is getting a CORS error when calling my FastAPI on localhost:8000.
> `Access to fetch at 'http://localhost:8000/api/chat' from origin 'http://localhost:3000' has been blocked by CORS policy`

**ChatGPT:**
Add CORSMiddleware to your FastAPI app:

```python
from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "https://your-vercel-app.vercel.app"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

For production, replace the wildcard with your actual Vercel URL.

**Outcome:** Fixed. Also added the Vercel production URL to `allow_origins`.

---

## Session 3 — Render Procfile Not Picking Up Uvicorn

**Me:**
> My Render deployment is failing. The Procfile has:
> `web: uvicorn app.main:app --host 0.0.0.0 --port $PORT`
> But Render logs say: `bash: uvicorn: command not found`

**ChatGPT:**
Render's build step installs packages but you need to ensure the working directory is correct. Your Procfile is probably running from the repo root, but uvicorn is installed inside `/backend`. Change your Render Start Command to:

```
cd backend && uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

Or set the **Root Directory** in Render's service settings to `backend`.

Alternatively use a `render.yaml` with:
```yaml
services:
  - type: web
    name: o2c-backend
    env: python
    rootDir: backend
    buildCommand: pip install -r requirements.txt
    startCommand: uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

**Outcome:** Used the `render.yaml` approach. Deployment succeeded.

---

## Session 4 — Vercel Build Failing on React App

**Me:**
> Vercel build is failing with:
> `Error: ENOENT: no such file or directory, open '/vercel/path0/frontend/node_modules/.cache'`
> My repo root has `frontend/` and `backend/` folders.

**ChatGPT:**
You need to configure Vercel to treat `frontend/` as the root for the React app. In your Vercel project settings:
- **Framework Preset**: Create React App (or Vite if applicable)
- **Root Directory**: `frontend`
- **Build Command**: `npm run build`
- **Output Directory**: `build`

Or use a `vercel.json` at repo root:
```json
{
  "buildCommand": "cd frontend && npm install && npm run build",
  "outputDirectory": "frontend/build",
  "framework": "create-react-app"
}
```

**Outcome:** Added `vercel.json` with the correct paths. Vercel build passed.

---

## Session 5 — SQLite Database Path Issue on Render

**Me:**
> ETL runs fine locally but on Render after deploy, the FastAPI can't find the database:
> `sqlite3.OperationalError: unable to open database file`
> My db is created at `data/o2c_graph.db` relative to the backend folder.

**ChatGPT:**
On Render, the working directory when the app runs is the service root (which you set to `backend/`). So relative paths like `../data/o2c_graph.db` won't resolve correctly.

Best approach: use an absolute path constructed from `__file__`:

```python
import os
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.environ.get("DB_PATH", os.path.join(BASE_DIR, "data", "o2c_graph.db"))
```

Also note: Render's free tier has ephemeral storage. The DB resets on each deploy. For a demo, you can bundle a pre-built `.db` file into the repo and skip ETL on Render.

**Outcome:** Used the `__file__`-based path resolution. Committed a pre-built `o2c_graph.db` to the repo for the demo deployment.

---

## Session 6 — npm start Opening Wrong Port

**Me:**
> After `npm start` my React app opens on port 3001 instead of 3000. Something else is using 3000. My `api.js` is hardcoded to `localhost:3000`. How do I handle environment-based API URLs in Create React App?

**ChatGPT:**
Use environment variables with the `REACT_APP_` prefix (required by CRA):

Create `.env.development`:
```
REACT_APP_API_URL=http://localhost:8000
```

Create `.env.production`:
```
REACT_APP_API_URL=https://your-render-backend.onrender.com
```

In your `api.js`:
```javascript
const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:8000';
```

**Outcome:** Implemented this pattern. Now the frontend correctly targets the right backend in both dev and prod.

---

## Session 7 — ETL Script Failing on Missing JSONL Folders

**Me:**
> My ETL script crashes if any of the 19 expected data folders is missing:
> `FileNotFoundError: [Errno 2] No such file or directory: 'data/raw/purchase_orders'`
> I want it to skip missing folders gracefully.

**ChatGPT:**
Wrap each folder processing block in a try/except with a warning:

```python
import os, logging

for entity_type, config in ENTITY_CONFIG.items():
    folder_path = os.path.join(RAW_DATA_DIR, config["folder"])
    if not os.path.exists(folder_path):
        logging.warning(f"Skipping {entity_type}: folder not found at {folder_path}")
        continue
    # ... process files
```

Also add a summary at the end:
```python
logging.info(f"ETL complete. Loaded: {loaded_count} entities, skipped: {skipped_count} folders.")
```

**Outcome:** Added graceful skipping. ETL now runs with partial data for testing.

---

*These sessions covered environment setup and deployment configuration — quick practical fixes rather than architecture decisions. Architecture reasoning documented separately in claude-session-log.*
